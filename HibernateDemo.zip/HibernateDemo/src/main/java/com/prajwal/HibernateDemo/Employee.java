package com.prajwal.HibernateDemo; //pojo

import jakarta.persistence.Entity;

@Entity
public class Employee {
	private int empid;
	private String ename;
	private String edept;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEdept() {
		return edept;
	}
	public void setEdept(String edept) {
		this.edept = edept;
	}
	
}
